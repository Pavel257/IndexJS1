import * as math from './math.js';



console.log( math.multiply(5) );
console.log( math.sum(1,2) );

document.write('Hello, pack!!!!!55');


