const PI = 3.14;

export const sum = (a, b) =>  a + b;

export const multiply = (a) => a*PI;